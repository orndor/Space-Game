﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Space_Game
{
    class Global
    {
        static public decimal money = 42;
        static public byte currentPlanet = 1;
        static public byte age = 18;
        static public string name="Player";
        static public byte origin = 2;
        static public int gas = 100;
    }
}
