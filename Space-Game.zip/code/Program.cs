﻿using System;
using System.Collections.Generic;
using System.Threading;

namespace Space_Game
{
    class Program
    {
         
        static void Main(string[] args)
        {
            new App().Run();
        }
    }
}
